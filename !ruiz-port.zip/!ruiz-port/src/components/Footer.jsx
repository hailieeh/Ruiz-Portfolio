export default function Footer() {
  return (
    <footer className="footer">
      <p>© {new Date().getFullYear()} Hailie Jade Ruiz. All rights reserved.</p>
    </footer>
  );
}
