export default function About() {
  return (
    <section>
      <h1>About Me</h1>
      <p>
        I am a third-year Bachelor of Science in Information Technology student
        with an interest in technology, creativity, and digital work. I have
        basic programming skills, experience in graphic design, and knowledge of
        video editing. I also have experience working as a Virtual Assistant
        (VA) and in Social Media Management (SMM). I am always willing to learn
        new skills, explore opportunities, and improve my abilities.
      </p>

      <h2>Skills</h2>
      <ul>
        <li><strong>Programming:</strong> C, C#, Python</li>
        <li><strong>Graphic Design:</strong> Canva</li>
        <li><strong>Video Editing:</strong> Basic knowledge of CapCut</li>
        <li><strong>Virtual Assistance:</strong> Previous VA experience</li>
        <li><strong>Social Media Management:</strong> Previous SMM experience</li>
      </ul>
    </section>
  );
}
