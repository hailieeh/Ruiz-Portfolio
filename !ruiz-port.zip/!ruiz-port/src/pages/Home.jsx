import { Link } from "react-router-dom";

export default function Home() {
  return (
    <section>
      <h1>Hi, I'm Hailie Jade Ruiz</h1>
      <p className="subtitle">BS Information Technology | 3rd Year Student</p>
      <p>
        Welcome to my portfolio. I'm interested in technology, creativity, and
        digital work. Take a look around!
      </p>
      <Link to="/projects" className="button">View my projects</Link>
    </section>
  );
}
