export default function Contact() {
  return (
    <section>
      <h1>Contact</h1>
      <p>Want to get in touch? Reach out through email.</p>
      <p>
        <strong>Email:</strong>{" "}
        <a href="mailto:202311677@gordoncollege.edu.ph">
          202311677@gordoncollege.edu.ph
        </a>
      </p>
    </section>
  );
}
