# Ruiz Portfolio

Personal portfolio of Hailie Jade Ruiz, BS Information Technology student.
Built with React, Vite and React Router. Work in progress (foundation version).

## Run locally

```bash
npm install
npm run dev
```
